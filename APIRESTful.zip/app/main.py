from fastapi import FastAPI
from app.router import products, categories, clients, pedidos
from app.db import mongodb

app = FastAPI()

mongodb.connect_to_mongo()

# Incluir las rutas
app.include_router(products.router)
app.include_router(categories.router)
app.include_router(clients.router)
app.include_router(pedidos.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to my FastAPI app with MongoDB!"}