from pydantic import BaseModel
from typing import Optional

# Esquema para productos
class Client(BaseModel):
    nombre: str
    apellido: str
    email: str

class ClientUpdate(BaseModel):
    nombre: Optional[str] = None
    apellido: Optional[str] = None
    email: Optional[int] = None