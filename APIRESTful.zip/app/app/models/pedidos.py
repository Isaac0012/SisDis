from bson import ObjectId
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import date, datetime

# Función para validar si el string es un ObjectId válido
def is_valid_objectid(id: str) -> bool:
    try:
        ObjectId(id)
        return True
    except:
        return False

# Esquema para un producto individual
class ListaProd(BaseModel):
    nombre_prod: str

# Esquema para pedidos
class Product(BaseModel):
    fecha: date
    total: float = 0.0
    productos: List[ListaProd] = []

    # Validador para convertir 'date' a 'datetime' automáticamente
    @validator('fecha', pre=True, always=True)
    def convert_fecha_to_datetime(cls, v):
        if isinstance(v, date):
            return datetime.combine(v, datetime.min.time())
        return v

    # Método para agregar un producto y actualizar el total
    def add_producto(self, nombre_prod: str, precio: float, cantidad: int):
        nuevo_producto = ListaProd(nombre_prod=nombre_prod, precio=precio, cantidad=cantidad)
        self.productos.append(nuevo_producto)
        # Actualiza el total
        self.total += precio * cantidad
