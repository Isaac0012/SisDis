from bson import ObjectId
from pydantic import BaseModel

# Función para validar si el string es un ObjectId válido
def is_valid_objectid(id: str) -> bool:
    try:
        ObjectId(id)
        return True
    except:
        return False

# Esquema para productos
class Category(BaseModel):
    nombre: str
    descripcion: str