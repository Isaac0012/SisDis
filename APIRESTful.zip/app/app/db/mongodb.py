from motor import motor_asyncio

# Variables globales para la conexión
client = None
db = None

def connect_to_mongo():
    global client, db
    # Configurar la conexion con MongoDB
    MONGO_URI = "mongodb://localhost:27017"
    # Ejecutar el cliente de bases de datos
    client = motor_asyncio.AsyncIOMotorClient(MONGO_URI)
    db = client["sistemas_distribuidos"]
    print('Base de Datos conectada')

def close_mongo_connection():
    global client
    if client:
        client.close()
        print("MongoDB connection closed")