from bson import ObjectId
from fastapi import HTTPException
from app.db import mongodb
from app.models import products

# Crear un nuevo producto
async def create_product(product_data: dict) -> dict:
    result = await mongodb.db["products"].insert_one(product_data)
    # Obtener el producto recién creado usando su ObjectId
    new_product = await mongodb.db["products"].find_one({"_id": result.inserted_id})
    # Devolver el producto recién creado
    return new_product

# Obtener un producto por su ID
async def get_product(product_id: str):
    if not products.is_valid_objectid(product_id):
        raise HTTPException(status_code=400, detail="formato invalido de id")
    
    object_id = ObjectId(product_id)
    
    # Buscar el usuario por el ObjectId
    product = await mongodb.db["products"].find_one({"_id": object_id})
    
    print(product)
    # Si no se encuentra el usuario, lanzar excepción
    if not product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    
    # Retornar los datos del usuario
    return {
        "id": str(product["_id"]),
        "nombre": product["nombre"],
        "descripcion": product["descripcion"],
        "precio": product["precio"],
        "stock": product["stock"]
    }

# Obtener todos los productos
async def get_all_products():
    products = await mongodb.db["products"].find().to_list(None)

    print(products)
    # Convertir ObjectId a cadena y devolverlo junto con los demás campos
    results = [
        {
            "id": str(product["_id"]),
            "nombre": product["nombre"],
            "descripcion": product["descripcion"],
            "precio": product["precio"],
            "stock": product["stock"]
        }
        for product in products
    ]
    return results

# Actualizar un producto
async def update_product(product_id: str, product_data: dict):
    await mongodb.db["products"].update_one({"_id": ObjectId(product_id)}, {"$set": product_data})
    updated_product = await mongodb.db["products"].find_one({"_id": ObjectId(product_id)})
    if updated_product:
        return {
        "id": str(updated_product["_id"]),
        "nombre": updated_product["nombre"],
        "descripcion": updated_product["descripcion"],
        "precio": updated_product["precio"],
        "stock": updated_product["stock"]
    }
    return None

# Eliminar un producto
async def delete_product(product_id: str):
    result = await mongodb.db["products"].delete_one({"_id": ObjectId(product_id)})
    return result.deleted_count