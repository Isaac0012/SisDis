from bson import ObjectId
from fastapi import HTTPException
from app.db import mongodb
from app.models import category

# Crear una nueva categoria
async def create_category(category_data: dict) -> dict:
    result = await mongodb.db["categories"].insert_one(category_data)
    # Obtener el producto recién creado usando su ObjectId
    new_category = await mongodb.db["categories"].find_one({"_id": result.inserted_id})
    # Devolver el producto recién creado
    return {
        "message": "Se ha creado la categoria correctamente"
    }

# Obtener un producto por su ID
async def get_category(category_id: str):
    if not category.is_valid_objectid(category_id):
        raise HTTPException(status_code=400, detail="formato invalido de id")
    
    object_id = ObjectId(category_id)
    
    # Buscar el usuario por el ObjectId
    get_category = await mongodb.db["categories"].find_one({"_id": object_id})
    
    # Si no se encuentra el usuario, lanzar excepción
    if not get_category :
        raise HTTPException(status_code=404, detail="Categoria no encontrada")
    
    # Retornar los datos del usuario
    return {
        "id": str(get_category ["_id"]),
        "nombre": get_category ["nombre"],
        "descripcion": get_category ["descripcion"],
    }

# Obtener todos los productos
async def get_all_categories():
    categories = await mongodb.db["categories"].find().to_list(None)

    # Convertir ObjectId a cadena y devolverlo junto con los demás campos
    results = [
        {
            "id": str(category["_id"]),
            "nombre": category["nombre"],
            "descripcion": category["descripcion"],
        }
        for category in categories
    ]
    return results

# # Actualizar un producto
async def update_category(category_id: str, category_data: dict):
    await mongodb.db["categories"].update_one({"_id": ObjectId(category_id)}, {"$set": category_data})
    updated_category = await mongodb.db["categories"].find_one({"_id": ObjectId(category_id)})
    if updated_category:
        return {
        "id": str(updated_category["_id"]),
        "nombre": updated_category["nombre"],
        "descripcion": updated_category["descripcion"],
    }
    return None

# # Eliminar un producto
async def delete_category(category_id: str):
    result = await mongodb.db["categories"].delete_one({"_id": ObjectId(category_id)})
    return result.deleted_count