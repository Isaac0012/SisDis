from bson import ObjectId
from datetime import datetime, date
from app.db import mongodb
from app.models import pedidos

# Función para convertir 'date' a 'datetime' si es necesario
def convert_fecha(pedidos_data: dict) -> dict:
    if "fecha" in pedidos_data and isinstance(pedidos_data["fecha"], date):
        pedidos_data["fecha"] = datetime.combine(pedidos_data["fecha"], datetime.min.time())
    return pedidos_data

# Crear un nuevo pedido
async def create_pedidos(pedidos_data: dict) -> dict:
    pedidos_data = convert_fecha(pedidos_data)  # Convierte 'fecha' antes de insertar
    new_pedidos = await mongodb.db["pedidos"].insert_one(pedidos_data)
    created_pedidos = await mongodb.db["pedidos"].find_one({"_id": new_pedidos.inserted_id})
    if created_pedidos:
        return pedidos.Product(**created_pedidos)
    return None

# Obtener un pedido por su ID
async def get_pedidos(pedidos_id: str) -> dict:
    pedido = await mongodb.db["pedidos"].find_one({"_id": ObjectId(pedidos_id)})
    if pedido:
        return pedidos.Product(**pedido)
    return None

# Obtener todos los pedidos
from pydantic import ValidationError

async def get_all_pedidos() -> list:
    pedidos_list = []
    cursor = mongodb.db["pedidos"].find()
    async for pedido in cursor:
        try:
            pedidos_list.append(pedidos.Product(**pedido))
        except ValidationError as e:
            print(f"Error de validación en el pedido: {pedido}")
            print(f"Detalles del error: {e}")
    return pedidos_list



# Actualizar un pedido
async def update_pedidos(pedidos_id: str, pedidos_data: dict):
    pedidos_data = convert_fecha(pedidos_data)  # Convierte 'fecha' antes de actualizar
    result = await mongodb.db["pedidos"].update_one({"_id": ObjectId(pedidos_id)}, {"$set": pedidos_data})
    if result.matched_count:
        updated_pedidos = await mongodb.db["pedidos"].find_one({"_id": ObjectId(pedidos_id)})
        if updated_pedidos:
            return pedidos.Product(**updated_pedidos)
    return None

# Eliminar un pedido
async def delete_pedidos(pedidos_id: str):
    result = await mongodb.db["pedidos"].delete_one({"_id": ObjectId(pedidos_id)})
    return result.deleted_count
