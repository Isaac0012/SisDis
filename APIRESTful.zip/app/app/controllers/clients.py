from bson import ObjectId
from fastapi import HTTPException
from app.db import mongodb
from app.models.clients import Client, ClientUpdate

# Función para validar si el string es un ObjectId válido
def is_valid_objectid(id: str) -> bool:
    try:
        ObjectId(id)
        return True
    except:
        return False

# Crear un nuevo cliente
async def create_client(client_data: dict) -> dict:
    result = await mongodb.db["clients"].insert_one(client_data)
    # Agregar el ID del documento a los datos del cliente
    client_data["id"] = str(result.inserted_id)
    return client_data  # Retornar los datos del cliente creado

# Obtener todos los clientes de la bd
async def get_clients():
    clients = await mongodb.db["clients"].find().to_list(None)
    # Convertir ObjectId a cadena y devolverlo junto con los demás campos
    results = [
        {
            "id": str(client["_id"]),
            "nombre": client["nombre"],
            "apellido": client["apellido"],
            "email": client["email"]
        }
        for client in clients
    ]
    return results

# Obtener cliente por id
async def get_client_by_id(client_id: str):
    # Mensaje si el formato de id NO es valido
    if not is_valid_objectid(client_id):
        raise HTTPException(status_code=400, detail="formato invalido de id")
    
    object_id = ObjectId(client_id)
    
    # Buscar el usuario por el ObjectId
    client = await mongodb.db["clients"].find_one({"_id": object_id})
    
    # Si no se encuentra el usuario, lanzar excepción
    if not client:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    # Retornar los datos del usuario
    return {
        "id": str(client["_id"]),
        "nombre": client["nombre"],
        "apellido": client["apellido"],
        "email": client["email"]
    }

# Actualizar cliente por id
async def update_client_by_id(client_id: str, client: ClientUpdate):
    update_data = client.dict(exclude_unset=True)
    # Verificar si el ID es válido
    if not is_valid_objectid(client_id):
        raise HTTPException(status_code=400, detail="Formato inválido de ID")
    
    object_id = ObjectId(client_id)

    # Buscar el usuario por el ObjectId
    existing_user = await mongodb.db["clients"].find_one({"_id": object_id})

    if not existing_user:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    # Si no se proporcionó ningún campo para actualizar, devolver un error
    if not update_data:
        raise HTTPException(status_code=400, detail="No se proporcionaron datos para actualizar")

    # Actualizar el usuario en la base de datos sin modificar el _id
    update_result = await mongodb.db["clients"].update_one(
        {"_id": object_id},  # Filtro para encontrar el usuario
        {"$set": update_data}  # Solo actualizar los campos especificados
    )
    
    # Verificar si se realizó alguna actualización
    if update_result.modified_count == 0:
        raise HTTPException(status_code=400, detail="No se pudo actualizar el usuario")

    # Retornar la respuesta exitosa
    return {
        "message": "Usuario actualizado con éxito",
    }

# Borrar cliente por id
async def delete_client_by_id(client_id: str):
    if not is_valid_objectid(client_id):
        raise HTTPException(status_code=400, detail="formato invalido de id")

    object_id = ObjectId(client_id)
    
    # Buscar y eliminar el usuario por el ObjectId
    result = await mongodb.db["clients"].delete_one({"_id": object_id})
    
    # Si no se encuentra el usuario, lanzar excepción
    if result.deleted_count == 1:
        return{
            "message": "Usuario eliminado"
        }
    else:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")