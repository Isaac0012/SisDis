from fastapi import APIRouter, HTTPException
from app.controllers import clients
from app.models.clients import Client, ClientUpdate

router = APIRouter()

# Crear un cliente
@router.post("/clients", response_model=Client)
async def create_new_client(client: Client):
    return await clients.create_client(client.dict())

# Obtener todos los clientes de la base de datos
@router.get("/clients")
async def get_all_clientes():
    return await clients.get_clients()

# Obtener un cliente por id
@router.get("/clients/{client_id}")
async def get_by_id(client_id: str):
    return await clients.get_client_by_id(client_id)

# Actualizar datos de un cliente por id
@router.put("/clients/{client_id}")
async def update_by_id(client_id: str, client: ClientUpdate):
    return await clients.update_client_by_id(client_id, client)

# Borrar cliente por id
@router.delete("/clients/{client_id}")
async def delete_by_id(client_id: str):
    return await clients.delete_client_by_id(client_id)