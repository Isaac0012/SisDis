from fastapi import APIRouter, HTTPException
from app.controllers import pedidos
from app.models.pedidos import Product
from typing import List


router = APIRouter()

# Crear un pedido
@router.post("/pedidos", response_model=Product)
async def create_new_pedidos(pedido: Product):
    return await pedidos.create_pedidos(pedido.dict())

@router.get("/pedidos", response_model=List[Product])
async def get_pedidos():
    return await pedidos.get_all_pedidos()

# Obtener un pedido por ID
@router.get("/pedidos/{pedidos_id}", response_model=Product)
async def get_pedidos_by_id(pedidos_id: str):
    pedido = await pedidos.get_pedidos(pedidos_id)
    if pedido is None:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")
    return pedido

# Actualizar un pedido
@router.put("/pedidos/{pedidos_id}", response_model=Product)
async def update_existing_pedidos(pedidos_id: str, pedido: Product):
    updated_pedidos = await pedidos.update_pedidos(pedidos_id, pedido.dict())
    if updated_pedidos is None:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")
    return updated_pedidos

# Eliminar un pedido
@router.delete("/pedidos/{pedidos_id}")
async def delete_pedidos_by_id(pedidos_id: str):
    delete_count = await pedidos.delete_pedidos(pedidos_id)  # Cambiado a 'delete_product'
    if delete_count == 0:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")
    return {"message": "Pedido eliminado exitosamente"}
