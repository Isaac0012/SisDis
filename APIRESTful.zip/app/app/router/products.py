from fastapi import APIRouter, HTTPException
from app.controllers import products
from app.models.products import Product

router = APIRouter()

# Crear un producto
@router.post("/products", response_model=Product)
async def create_new_product(product: Product):
    return await products.create_product(product.dict())

# Obtener todos los productos
@router.get("/products")
async def get_products():
    return await products.get_all_products()

# Obtener un producto por ID
@router.get("/products/{product_id}")
async def get_product_by_id(product_id: str):
    product = await products.get_product(product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

# Actualizar un producto
@router.put("/products/{product_id}")
async def update_existing_product(product_id: str, product: Product):
    updated_product = await products.update_product(product_id, product.dict())
    if updated_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return updated_product

# Eliminar un producto
@router.delete("/products/{product_id}")
async def delete_product_by_id(product_id: str):
    delete_count = await products.delete_product(product_id)
    if delete_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Producto eliminado satisfactoriamente"}