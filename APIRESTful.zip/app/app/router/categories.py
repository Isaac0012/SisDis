from fastapi import APIRouter, HTTPException
from app.controllers import categories
from app.models.category import Category

router = APIRouter()

# Crear un producto
@router.post("/categories")
async def create_new_category(category: Category):
    return await categories.create_category(category.dict())

# Obtener todos los productos
@router.get("/categories")
async def get_categories():
    return await categories.get_all_categories()

# # Obtener un producto por ID
@router.get("/categories/{category_id}")
async def get_categories_by_id(category_id: str):
    category = await categories.get_category(category_id)
    if category is None:
        raise HTTPException(status_code=404, detail="No se encontró la categoría")
    return category

# # Actualizar un producto
@router.put("/categories/{category_id}")
async def update_existing_category(category_id: str, category: Category):
    updated_category = await categories.update_category(category_id, category.dict())
    if updated_category is None:
        raise HTTPException(status_code=404, detail="No se encontró la categoría")
    return updated_category

# Eliminar un producto
@router.delete("/categories/{category_id}")
async def delete_category_by_id(category_id: str):
    delete_count = await categories.delete_category(category_id)
    if delete_count == 0:
        raise HTTPException(status_code=404, detail="No se encontró la categoría")
    return {"message": "Producto eliminado satisfactoriamente"}